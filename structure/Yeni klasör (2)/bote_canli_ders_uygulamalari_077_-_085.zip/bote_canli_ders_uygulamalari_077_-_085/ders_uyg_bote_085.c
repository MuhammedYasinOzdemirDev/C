// Canl� Ders Uygulamas� - No: 085
// 0 girene kadar kullan�c�n�n girdi�i (maks 10 basamakl�)
// say�lar� sola dayal� toplama i�lemi yaparak toplar.
// Geli�tirilmesi gerekiyor..


/*

45898621
5847
498959656
545
0
----------

*/

#include <stdio.h>

main () {
     
     long long int sayi, depo, toplam = 0;
     int i, maks = 0, adet;
     
     while (1) {
           
        scanf ("%lld", &sayi);   
        
        if (sayi == 0)
           break;
           
        adet = 0;
        depo = sayi;
        
        while (depo > 0) {
              adet ++;
              depo = depo / 10;
        }
        
        if (adet > maks)
            maks = adet;
        
        for (i=1; i<=10-adet; i++)
            sayi = sayi * 10;
           
        toplam = toplam + sayi;
     
     }
     
     for (i=1; i<=10-maks; i++)
        toplam = toplam / 10;
     
     printf ("\n%lld", toplam);
     
     getch ();  
}
