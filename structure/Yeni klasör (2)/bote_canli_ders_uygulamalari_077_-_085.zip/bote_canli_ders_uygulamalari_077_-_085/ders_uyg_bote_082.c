// Canl� Ders Uygulamas� - No: 082
// Negatif bir say� yaz�lana kadar girilen say�lardan ka��n�n tek
// ka��n�n �ift say�n� oldu�unu bulur.

#include <stdio.h>

main () {
     
     int sayi, tek = 0, cift = 0;
     
     while (1) {
           
           printf ("Sayi giriniz: ");
           scanf ("%d", &sayi);
           
           if (sayi < 0)
               break;
           
           if (sayi % 2 == 0)
              cift ++;
           else
              tek ++;
     }
     
     printf ("\nTek sayi adedi = %d\nCift sayi adedi = %d", tek, cift);        
     getch ();  
}
