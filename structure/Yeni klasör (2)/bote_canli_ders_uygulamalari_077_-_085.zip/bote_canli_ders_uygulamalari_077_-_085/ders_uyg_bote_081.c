// Canl� Ders Uygulamas� - No: 081
// Girilen kenar uzunlu�una ve deseni olu�turacak rakama g�re; belirtilen 
// rakamdan olu�an 3 desenini olu�turur.

/*

3 3 3 3 3
        3
        3
        3       
3 3 3 3 3
        3
        3
        3
3 3 3 3 3

*/

#include <stdio.h>

main () {
     
     int uzunluk, rakam, i, j, k;
     
     printf ("Once uzunlugu sonra rakami giriniz: ");
     scanf ("%d %d", &uzunluk, &rakam);
     
     printf ("\n");
     
     for (i=1; i<=uzunluk; i++)
         printf ("%d ", rakam);
     
     for (k=1; k<=2; k++) {
     
         for (i=1; i<=uzunluk-2; i++) {
             
             printf ("\n");
             
             for (j=1; j<=uzunluk-1; j++)
                 printf ("  ");
             
             printf ("%d ", rakam);
         
         }
         
         printf ("\n");
         
         for (i=1; i<=uzunluk; i++)
             printf ("%d ", rakam);
     
     }
             
     getch ();  
}
