// Canl� Ders Uygulamas� - No: 084
// Kullan�c�n�n girdi�i 3 ila 8 basamakl� bir say� i�erisinde
// yine kullan�c�n�n girdi�i 2 basamakl� say�n�n olup olmad��� bulur

#include <stdio.h>

main () {
     
     int sayi, arama, buldum = 0;
     
     printf ("Iki sayi giriniz: ");
     scanf ("%d %d", &sayi, &arama);
     
     while (sayi > 9) {
           
           if (sayi % 100 == arama)
              buldum = 1;
              
           sayi = sayi / 10;
     
     }
     
     if (buldum == 0)
         printf ("OLUMSUZ");
         
     else
         printf ("OLUMLU");
            
     getch ();  
}
