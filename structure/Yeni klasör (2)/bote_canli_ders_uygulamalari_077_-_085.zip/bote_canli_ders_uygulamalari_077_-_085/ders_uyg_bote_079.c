// Canl� Ders Uygulamas� - No: 079
// 

#include <stdio.h>

main () {
     
     int a, b, c, d, e, adet1 = 0, adet2 = 0;
     
     for (a=0; a<10; a++)   
         for (b=0; b<10; b++) 
             for (c=0; c<10; c++)   
                 for (d=0; d<10; d++)    
                     for (e=0; e<10; e++) {  
                     
                         adet1 ++;
                               
                         if (a<=b && b<=c && c<=d && d<=e) {
                            // printf ("%d %d %d %d %d\n", a, b, c, d, e);  
                            adet2 ++;
                         } 
                     }  
     
     printf ("\nOlasilik yuzdesi = %.2f", (float)adet2/adet1 * 100);
     getch ();  
}
