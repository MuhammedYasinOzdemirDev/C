// Canl� Ders Uygulamas� - No: 080
// Girilen kenar uzunlu�una ve deseni olu�turacak rakama g�re; belirtilen 
// rakamdan olu�an H harfini olu�turur.

/*

2       2
2       2
2       2
2       2
2 2 2 2 2
2       2
2       2
2       2
2       2


*/

#include <stdio.h>

main () {
     
     int uzunluk, rakam, i, j;
     
     printf ("Seklin kenar uzunlugunu giriniz: ");
     scanf ("%d", &uzunluk);
     
     printf ("Deseni olusturacak rakami giriniz: ");
     scanf ("%d", &rakam);
     
     printf ("\n");
     
     for (i=1; i<=uzunluk-1; i++) {
         
         printf ("%d ", rakam);
         
         for (j=1; j<=uzunluk-2; j++)
             printf ("  ");
             
         printf ("%d \n", rakam);
     }
     
     for (i=1; i<=uzunluk; i++)
         printf ("%d ", rakam);
         
     printf ("\n");
         
     for (i=1; i<=uzunluk-1; i++) {
         
         printf ("%d ", rakam);
         
         for (j=1; j<=uzunluk-2; j++)
             printf ("  ");
             
         printf ("%d \n", rakam);
     }
             
     getch ();  
}
