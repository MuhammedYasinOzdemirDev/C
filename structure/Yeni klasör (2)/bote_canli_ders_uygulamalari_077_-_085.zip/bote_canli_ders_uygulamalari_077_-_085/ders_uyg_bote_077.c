// Canl� Ders Uygulamas� - No: 077
// Vize Deneme S�nav� - Soru 1 - Alternatif ��z�m

#include <stdio.h>

main () {
     
     long long int dizi[90] = {0, 1}, sayi1, sayi2;
     int i, hedef;
     
     printf ("Ardisik iki dizi terimi giriniz: ");
     scanf ("%lld %lld", &sayi1, &sayi2);
      
     for (i=2; i<90; i++)
          dizi[i] = dizi[i-1] + dizi[i-2];

     for (i=0; dizi[i] != sayi1; i++);
     
     hedef = i - 1;
     
     for (i=hedef; i>=0; i--)
         printf ("%lld ", dizi[i]);
         
     getch ();  
}
