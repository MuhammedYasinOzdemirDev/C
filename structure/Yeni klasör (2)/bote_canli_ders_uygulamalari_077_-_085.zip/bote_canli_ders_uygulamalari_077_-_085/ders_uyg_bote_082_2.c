// Canl� Ders Uygulamas� - No: 082
// 0 girilen kadar yaz�lana kadar rakamlardan ka��n�n tek ka��n�n �ift oldu�unu bulur.
// Enter tu�una bas�lmas� yasak.

/*

Sayi giriniz: 5 8 9 4 7 1 0

*/

#include <stdio.h>

main () {
     
     int sayi, tek = 0, cift = 0;
     
     printf ("Sayi giriniz: ");
     
     while (1) {
           
           sayi = getch () - 48;
           printf ("%d ", sayi);
           
           if (sayi == 0)
               break;
           
           if (sayi % 2 == 0)
              cift ++;
           else
              tek ++;
     }
     
     printf ("\n\nTek sayi adedi = %d\nCift sayi adedi = %d", tek, cift);        
     getch ();  
}
